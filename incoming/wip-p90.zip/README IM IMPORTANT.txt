Just put the .pak file in [Openspades folder]/Resources
PS: DO NOT RENAME THE FILE NAME OR ELSE IT WILL NOT WORK! 