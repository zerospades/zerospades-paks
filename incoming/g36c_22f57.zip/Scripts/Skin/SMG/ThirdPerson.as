/*
 Copyright (c) 2013 yvt
 Modified by Paratrooper
 
 This file is part of OpenSpades.

 OpenSpades is free software: you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation, either version 3 of the License, or
 (at your option) any later version.

 OpenSpades is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with OpenSpades.  If not, see <http://www.gnu.org/licenses/>.

 */

 namespace spades {
    class ThirdPersonSMGSkin:
    IToolSkin, IThirdPersonToolSkin, IWeaponSkin, IWeaponSkin2 {
        private float sprintState;
        private float raiseState;
        private Vector3 teamColor;
        private bool muted = true;
        private Matrix4 originMatrix;
        private float aimDownSightState;
        private float readyState;
        private bool reloading;
        private float reloadProgress;
        private int ammo, clipSize;

        private float environmentRoom;
        private float environmentSize;
        private float environmentDistance;
        private Vector3 soundOrigin;

		private ConfigItem g36c_rgbSpeed("g36c_rgbSpeed", "0.1");
		private float Time;

        float SprintState {
            set { sprintState = value; }
        }

        float RaiseState {
            set { raiseState = value; }
        }

        bool IsMuted {
            set { muted = value; }
        }

        Vector3 TeamColor {
            set { teamColor = value; }
        }

        Matrix4 OriginMatrix {
            set { originMatrix = value; }
        }

        float PitchBias {
            get { return 0.f; }
        }

        float AimDownSightState {
            set { aimDownSightState = value; }
        }

        bool IsReloading {
            set { reloading = value; }
        }
        float ReloadProgress {
            set { reloadProgress = value; }
        }
        int Ammo {
            set { ammo = value; }
        }
        int ClipSize {
            set { clipSize = value; }
        }

        float ReadyState {
            set { readyState = value; }
        }

        // IWeaponSkin2
        void SetSoundEnvironment(float room, float size, float distance) {
            environmentRoom = room;
            environmentSize = size;
            environmentDistance = distance;
        }
        Vector3 SoundOrigin {
            set { soundOrigin = value; }
        }

        private Renderer@ renderer;
        private AudioDevice@ audioDevice;
        private Model@ gunModel1;
		private Model@ gunModel2;
		private Model@ gunModel3;
		private Model@ gunModel4;
		private Model@ gunModel5;

        private AudioChunk@[] fireMediumSounds(4);
        private AudioChunk@ fireFarSound;
        private AudioChunk@ fireStereoSound;
        private AudioChunk@[] fireSmallReverbSounds(4);
        private AudioChunk@[] fireLargeReverbSounds(4);
        private AudioChunk@ reloadSound;

        ThirdPersonSMGSkin(Renderer@ r, AudioDevice@ dev) {
            @renderer = r;
            @audioDevice = dev;
            @gunModel1 = renderer.RegisterModel
                ("Models/Weapons/SMG/ThirdP1.kv6");
			@gunModel2 = renderer.RegisterModel
                ("Models/Weapons/SMG/ThirdP2.kv6");
			@gunModel3 = renderer.RegisterModel
                ("Models/Weapons/SMG/ThirdP3.kv6");
			@gunModel4 = renderer.RegisterModel
                ("Models/Weapons/SMG/ThirdP4.kv6");
			@gunModel5 = renderer.RegisterModel
                ("Models/Weapons/SMG/ThirdP5.kv6");

            @fireMediumSounds[0] = dev.RegisterSound
                ("Sounds/Weapons/SMG/V2Third1.opus");
            @fireMediumSounds[1] = dev.RegisterSound
                ("Sounds/Weapons/SMG/V2Third2.opus");
            @fireMediumSounds[2] = dev.RegisterSound
                ("Sounds/Weapons/SMG/V2Third3.opus");
            @fireMediumSounds[3] = dev.RegisterSound
                ("Sounds/Weapons/SMG/V2Third4.opus");

            @fireSmallReverbSounds[0] = dev.RegisterSound
                ("Sounds/Weapons/SMG/V2AmbienceSmall1.opus");
            @fireSmallReverbSounds[1] = dev.RegisterSound
                ("Sounds/Weapons/SMG/V2AmbienceSmall2.opus");
            @fireSmallReverbSounds[2] = dev.RegisterSound
                ("Sounds/Weapons/SMG/V2AmbienceSmall3.opus");
            @fireSmallReverbSounds[3] = dev.RegisterSound
                ("Sounds/Weapons/SMG/V2AmbienceSmall4.opus");

            @fireLargeReverbSounds[0] = dev.RegisterSound
                ("Sounds/Weapons/SMG/V2AmbienceLarge1.opus");
            @fireLargeReverbSounds[1] = dev.RegisterSound
                ("Sounds/Weapons/SMG/V2AmbienceLarge2.opus");
            @fireLargeReverbSounds[2] = dev.RegisterSound
                ("Sounds/Weapons/SMG/V2AmbienceLarge3.opus");
            @fireLargeReverbSounds[3] = dev.RegisterSound
                ("Sounds/Weapons/SMG/V2AmbienceLarge4.opus");

            @fireFarSound = dev.RegisterSound
                ("Sounds/Weapons/SMG/FireFar.opus");
            @fireStereoSound = dev.RegisterSound
                ("Sounds/Weapons/SMG/FireStereo.opus");
            @reloadSound = dev.RegisterSound
                ("Sounds/Weapons/SMG/Reload.opus");
        }

        void Update(float dt) {
		
		     Time += dt;
        }

        void WeaponFired(){
            if(!muted){
                Vector3 origin = soundOrigin;
                AudioParam param;
                param.volume = 9.f;
                audioDevice.Play(fireMediumSounds[GetRandom(fireMediumSounds.length)], origin, param);

                param.volume = 8.f * environmentRoom;
                param.referenceDistance = 10.f;
                if (environmentSize < 0.5f) {
                    audioDevice.Play(fireSmallReverbSounds[GetRandom(fireSmallReverbSounds.length)], origin, param);
                } else {
                    audioDevice.Play(fireLargeReverbSounds[GetRandom(fireLargeReverbSounds.length)], origin, param);
                }

                param.volume = .4f;
                param.referenceDistance = 10.f;
                audioDevice.Play(fireFarSound,  origin, param);
                param.referenceDistance = 1.f;
                audioDevice.Play(fireStereoSound, origin, param);
            }
        }

        void ReloadingWeapon() {
            if(!muted){
                Vector3 origin = soundOrigin;
                AudioParam param;
                param.volume = 0.2f;
                audioDevice.Play(reloadSound, origin, param);
            }
        }

        void ReloadedWeapon() {
        }
		
		Vector3 HSV2RGB(float h, float s, float v) {
            if (s == 0.0F)
                return Vector3(v, v, v);

            int i = int(h * 6.0F);
            float f = h * 6.0F - i;
            float p = v * (1.0F - s);
            float q = v * (1.0F - s * f);
            float t = v * (1.0F - s * (1.0F - f));

            i = i % 6;
            switch (i) {
                case 0: return Vector3(v, t, p);
                case 1: return Vector3(q, v, p);
                case 2: return Vector3(p, v, t);
                case 3: return Vector3(p, q, v);
                case 4: return Vector3(t, p, v);
                case 5: return Vector3(v, p, q);
            }

            return Vector3(0, 0, 0);
        }

        Vector3 RGB(float speed) {
            speed = 0.002F * speed;
            auto h = (int(Time * 1000) % int(1.0F / speed)) * speed;
            return HSV2RGB(h, 1.0F, 1.0F);
        }

        void AddToScene() {
            Matrix4 mat = CreateScaleMatrix(0.004);
            mat = mat * CreateScaleMatrix(-1.f, -1.f, 1.f);
			
            mat *= CreateTranslateMatrix(-100.f, 278.f, -20.f);
            
            ModelRenderParam param;
			param.customColor = RGB(g36c_rgbSpeed.FloatValue);
            param.matrix = originMatrix * mat;
			renderer.AddModel(gunModel1, param);
			renderer.AddModel(gunModel2, param);
			renderer.AddModel(gunModel3, param);
			renderer.AddModel(gunModel4, param);
			renderer.AddModel(gunModel5, param);

        }
    }

    IWeaponSkin@ CreateThirdPersonSMGSkin(Renderer@ r, AudioDevice@ dev) {
        return ThirdPersonSMGSkin(r, dev);
    }
}
