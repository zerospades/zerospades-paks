
Winter Cammo skin for the Semi-AWPtomatic.

Put these files into the RESOURCES folder in your open spades directory!

=======================================================================================
Do NOT put them into the pak010-BaseSkin folder that most youtube tutorials tell you to.
=======================================================================================

All credits for modeling and coding go do PTrooper. All I did was re-skin.

Enjoy the skin,
|EzPz|