/*
 Copyright (c) 2013 yvt

 This file is part of OpenSpades.

 OpenSpades is free software: you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation, either version 3 of the License, or
 (at your option) any later version.

 OpenSpades is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with OpenSpades.  If not, see <http://www.gnu.org/licenses/>.

 */

 namespace spades {
	class ViewShotgunSkin:
	IToolSkin, IViewToolSkin, IWeaponSkin,
	BasicViewWeapon {

		private AudioDevice@ audioDevice;
		private AudioChunk@ fireSound;
		private AudioChunk@ fireSound2;
		private AudioChunk@ fireFarSound;
		private AudioChunk@ fireStereoSound;
		private AudioChunk@ fireSmallReverbSound;
		private AudioChunk@ fireLargeReverbSound;
		private AudioChunk@ reloadSound;
		private AudioChunk@ cockSound;
		
		private ConfigItem doom_png("doom_png", "1");
		private ConfigItem doom_sound("doom_sound", "0");

		private Image@ idle;
		private Image@ Reload0;
		private Image@ Reload1;
		private Image@ Reload2;
		private Image@ Reload3;
		private Image@ Reload4;
		private Image@ Shoot1;
		private Image@ Shoot2;
		private Image@ Shoot3;
		private Image@ Shoot4;
		private Image@ Shoot5;
		private Image@ Shoot6;
		private Image@ Shoot7;
		private Image@ sprint;
		
		ViewShotgunSkin(Renderer@ r, AudioDevice@ dev){
			super(r);
			@audioDevice = dev;
			
			@fireSound = dev.RegisterSound("Sounds/Weapons/Shotgun/FireLocal.opus");
			@fireSound2 = dev.RegisterSound("Sounds/Weapons/Shotgun/FireLocal.wav");
				
			@fireFarSound = dev.RegisterSound
				("Sounds/Weapons/Shotgun/FireFar.opus");
			@fireStereoSound = dev.RegisterSound
				("Sounds/Weapons/Shotgun/FireStereo.opus");
			@reloadSound = dev.RegisterSound
				("Sounds/Weapons/Shotgun/ReloadLocal.opus");
			@cockSound = dev.RegisterSound
				("Sounds/Weapons/Shotgun/CockLocal.opus");

			@fireSmallReverbSound = dev.RegisterSound
				("Sounds/Weapons/Shotgun/V2AmbienceSmall.opus");
			@fireLargeReverbSound = dev.RegisterSound
				("Sounds/Weapons/Shotgun/V2AmbienceLarge.opus");
				
			@idle = renderer.RegisterImage("Gfx/Idle.png");
			@Reload0 = renderer.RegisterImage("Gfx/Reload0.png");
			@Reload1 = renderer.RegisterImage("Gfx/Reload1.png");
			@Reload2 = renderer.RegisterImage("Gfx/Reload2.png");
			@Reload3 = renderer.RegisterImage("Gfx/Reload3.png");
			@Reload4 = renderer.RegisterImage("Gfx/Reload4.png");
			
			@Shoot1 = renderer.RegisterImage("Gfx/Shoot1.png");
			@Shoot2 = renderer.RegisterImage("Gfx/Shoot2.png");
			@Shoot3 = renderer.RegisterImage("Gfx/Shoot3.png");
			@Shoot4 = renderer.RegisterImage("Gfx/Shoot4.png");
			@Shoot5 = renderer.RegisterImage("Gfx/Shoot5.png");
			@Shoot6 = renderer.RegisterImage("Gfx/Shoot6.png");
			@Shoot7 = renderer.RegisterImage("Gfx/Shoot7.png");
			
			@sprint = renderer.RegisterImage("Gfx/Sprint.png");
		}
		
		void Update(float dt) {
			BasicViewWeapon::Update(dt);
		}

		void WeaponFired(){
			BasicViewWeapon::WeaponFired();
			if(!IsMuted){
				Vector3 origin = Vector3(0.4f, -0.3f, 0.5f);
				AudioParam param;
				param.volume = 8.f;
				
				if(doom_sound.FloatValue == 0){
					audioDevice.PlayLocal(fireSound, origin, param);
				}else{
					audioDevice.PlayLocal(fireSound2, origin, param);
				}

				param.volume = 8.f * environmentRoom;
				if (environmentSize < 0.5f) {
					audioDevice.PlayLocal(fireSmallReverbSound, origin, param);
				} else {
					audioDevice.PlayLocal(fireLargeReverbSound, origin, param);
				}

				param.volume = 2.f;
				audioDevice.PlayLocal(fireFarSound, origin, param);
				audioDevice.PlayLocal(fireStereoSound, origin, param);
			}
		}

		void ReloadingWeapon() {
			if(!IsMuted){
				Vector3 origin = Vector3(0.4f, -0.3f, 0.5f);
				AudioParam param;
				param.volume = 0.2f;
				audioDevice.PlayLocal(reloadSound, origin, param);
			}
		}

		void ReloadedWeapon() {
			if(!IsMuted){
				Vector3 origin = Vector3(0.4f, -0.3f, 0.5f);
				AudioParam param;
				param.volume = 0.2f;
				audioDevice.PlayLocal(cockSound, origin, param);
			}
		}

		float GetZPos() {
			return 0.2f - AimDownSightStateSmooth * 0.0535f;
		}

		void Draw2D() {
			if(AimDownSightState > 0.6){
				string str = "Gfx/Scope/default.png";
				switch(doom_png.IntValue){
					case 0: str = "Gfx/Scope/default.png"; break;
					case 1: str = "Gfx/Scope/scope1.png"; break;
					case 2: str = "Gfx/Scope/scope2.png"; break;
					case 3: str = "Gfx/Scope/scope3.png"; break;
					default: str = "Gfx/Scope/scope1.png"; break;	
				}
				Image@ img = renderer.RegisterImage(str);
				float height = renderer.ScreenHeight;
				float width = height * (800.f / 600.f); 
				renderer.Color = (Vector4(1.f, 1.f, 1.f, 1.f));
				renderer.DrawImage(img,
				AABB2((renderer.ScreenWidth - width) * 0.5f,
				(renderer.ScreenHeight - height) * 0.5f,
				width, height));
				return;
			}else{
				BasicViewWeapon::Draw2D();
			}
		}
		
		Matrix4 GetViewWeaponMatrix2() {
			Matrix4 mat;
			if(raiseState < 1.f) {
				float putdown = 1.f - raiseState;
				mat = CreateRotateMatrix(Vector3(0.f, 0.f, 1.f),
					putdown * -1.3f) * mat;
				mat = CreateRotateMatrix(Vector3(0.f, 1.f, 0.f),
					putdown * 0.2f) * mat;
				mat = CreateTranslateMatrix(Vector3(0.1f, -0.3f, 0.1f)
					* putdown)  * mat;
			}

			Vector3 trans(0.f, 0.f, 0.f);
			trans += Vector3(-0.13f * (1.f - AimDownSightStateSmooth),
							 0.5f, GetZPos());
			trans += (swing/8) * GetMotionGain();
			trans += GetLocalFireVibrationOffset();
			mat = CreateTranslateMatrix(trans) * mat;

			return mat;
		}

		void AddToScene() {
			Matrix4 mat = CreateScaleMatrix(0.033f);
			mat = GetViewWeaponMatrix2() * mat;

			float reload = ReloadProgress;
			Matrix4 weapMatrix = eyeMatrix * mat;
	
			// reload action
			reload *= 0.5f;
			
			// motion blending parameter
			float cockFade = 1.f;
			if(IsReloading){
				if(reload < 0.25f || ammo < (clipSize - 1)) {
					cockFade = 0.f;
				}else{
					cockFade = (reload - 0.25f) * 10.f;
					cockFade = Min(cockFade, 1.f);
				}
			}
			renderer.ColorP = Vector4(1,1,1,1);
			if(AimDownSightState == 0){
				if(readyState < 0.1){
					renderer.AddSprite(Shoot1, weapMatrix * Vector3(4.f, -11.f, -4.f), 1.1f, 0.f);
				}else if(readyState < 0.2){
					renderer.AddSprite(Shoot2, weapMatrix * Vector3(4.f, -11.f, -4.f), 1.1f, 0.f);
				}else if(readyState < 0.3){
					renderer.AddSprite(Shoot3, weapMatrix * Vector3(4.f, -11.f, -4.f), 1.1f, 0.f);
				}else if(readyState < 0.4){
					renderer.AddSprite(Shoot4, weapMatrix * Vector3(4.f, -11.f, -4.f), 1.1f, 0.f);
				}else if(readyState < 0.5){
					renderer.AddSprite(Shoot5, weapMatrix * Vector3(4.f, -11.f, -4.f), 1.1f, 0.f);
				}else if(readyState < 0.6){
					renderer.AddSprite(Shoot6, weapMatrix * Vector3(4.f, -11.f, -4.f), 1.1f, 0.f);
				}else if(readyState < 0.7){
					renderer.AddSprite(Shoot7, weapMatrix * Vector3(4.f, -11.f, -4.f), 1.1f, 0.f);
				}else if(readyState > 0.7 && !IsReloading && SprintState < 0.01){
					renderer.AddSprite(idle, weapMatrix * Vector3(4.f, -11.f, -4.f), 1.1f, 0.f);
				}
				
				if(IsReloading){
					if(reload < 0.1f){
					renderer.AddSprite(Reload0, weapMatrix * Vector3(4.f, -11.f, -4.f), 1.1f, 0.f);
					}else if(reload < 0.2f){
						renderer.AddSprite(Reload1, weapMatrix * Vector3(4.f, -11.f, -4.f), 1.1f, 0.f);
					}else if(reload < 0.3f){
						renderer.AddSprite(Reload2, weapMatrix * Vector3(4.f, -11.f, -4.f), 1.1f, 0.f);
					} else if(reload < 0.4f){
						renderer.AddSprite(Reload3, weapMatrix * Vector3(4.f, -11.f, -4.f), 1.1f, 0.f);
					} else if(reload < 0.5f){
						renderer.AddSprite(Reload4, weapMatrix * Vector3(4.f, -11.f, -4.f), 1.1f, 0.f);
					}  
				}
			
				if(SprintState > 0){
					renderer.AddSprite(sprint, weapMatrix * Vector3(3.f, -11.f, -3.6), 0.55f, 0.f);
				}
			}

			LeftHandPosition = mat * Vector3(0.f, -884.f, 2.f);
			RightHandPosition = mat * Vector3(0.f, -884.f, 2.f);
		}
	}

	IWeaponSkin@ CreateViewShotgunSkin(Renderer@ r, AudioDevice@ dev) {
		return ViewShotgunSkin(r, dev);
	}
}
