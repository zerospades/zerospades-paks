Barrett M107A1 (openspades only)
By sidex15

Warning: do not steal this mod without my permission!

Installation:
if you know how to install skip this step
1.go to openspades folder/resources/pack010-baseskin.pak.
  1a. if you have a pngsight mod just go pngsight-5.bak
2. open it in winrar
3. copy the contents into the selected .bak and click ok
Done :)

enjoy.
sidex15